import React, { Component } from 'react';

class Home extends Component {
    state = {  } 
    render() { 
        return (
            <h1>This is Home Page</h1>
        );
    }
}
 
export default Home;