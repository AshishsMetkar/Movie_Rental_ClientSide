import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
// import { getMovies } from "../services/fakeMovieService";
import { Link } from "react-router-dom";
import {
  deleteMovie,
  getAllMovies,
  getTotalNumberOfMovies,
} from "../actions/moviesActionCreator";
import Pagination from "./common/Pagination";
import ListGroup from "./common/ListGroup";
import { getAllGenres } from "../actions/genreActionCreator";

function MoviesFunc() {
  // const movies = getMovies();

  const dispatch = useDispatch();
  const movies = useSelector((state) => state.movieReducer.movies);
  const totalMovies = useSelector((state) => state.movieReducer.totalMovies);
  const genres = useSelector((state) => state.genreReducer.genres);
  const [pageSize] = useState(4);
  const [currentPage, setCurrentPage] = useState(1);
  const [genreName, setGenreName] = useState("");
 const [title, setTitleName]=useState("")
  useEffect(() => {
    let gName = "";
    if (genreName !== "All Genres") {
      gName = genreName;
    }
    dispatch(getAllMovies({ currentPage, pageSize, genreName: gName ,title}));
  }, []);

  useEffect(() => {
    dispatch(getAllGenres());
  }, []);

  useEffect(() => {
    let gName = "";
    if (genreName !== "All Genres") {
      gName = genreName;
    }
    dispatch(getTotalNumberOfMovies(gName,title));
  }, [movies]);

  const handlePageChange = (page) => {
    let gName = "";
    if (genreName !== "All Genres") {
      gName = genreName;
    }
    setCurrentPage(page);
    dispatch(getAllMovies({ currentPage: page, pageSize, genreName: gName,title }));
  };

  const handlePreviousChange = () => {
    if (currentPage > 1) {
      handlePageChange(currentPage - 1);
    }
  };

  const handleNextChange = () => {
    const totalPages = Math.ceil(totalMovies / pageSize);

    if (currentPage < totalPages) {
      handlePageChange(currentPage + 1);
    }
  };

  const handleGenreClick = (name) => {
    console.log(name);

    setGenreName(name);
    let gName = "";
    if (name !== "All Genres") {
      gName = name;
    }
    dispatch(getAllMovies({ currentPage, pageSize, genreName: gName,title }));
  };

  const handleInputChange =(e)=>{
    const {value} = e.target;
    console.log(value);
    setTitleName(value)
    let gName = "";
    if (genreName !== "All Genres") {
      gName = genreName;
    }
    dispatch(getAllMovies({currentPage,pageSize,genreName:gName,title:value}))
  }
  return (
    <div className="container-fluid">
      <div className="row">
        <div className="col-2 mt-5">
          <div class="input-group flex-nowrap mb-2 ">
            <span class="input-group-text" id="addon-wrapping">
            <i class="bi bi-search"></i>
            </span>
            <input
              type="text"
              class="form-control"
              placeholder="Movie-Title"
              aria-label="Username"
              aria-describedby="addon-wrapping"
              onChange={handleInputChange}
            />
          </div>
          <ListGroup
            items={[{ _id: "", name: "All Genres" }, ...genres]}
            onSelectItem={handleGenreClick}
            selectedItem={genreName}
          />
        </div>
        <div className="col-10">
          <h3 className="text-center my-4">Movie List</h3>
          <table className="table table-striped table-hover">
            <thead>
              <tr>
                <th className="col">#</th>
                <th className="col">Title</th>
                <th className="col">Genre Name</th>
                <th className="col">Daily Rental Rate</th>
                <th className="col">Number in Stock</th>
                <th className="col">Liked</th>
                <th className="col">Delete</th>
              </tr>
            </thead>
            <tbody>
              {movies.map((movie, index) => (
                <tr key={movie._id}>
                  <th scope="row">{index + 1}</th>
                  <td>
                    <Link to={`/movies/${movie._id}`}>{movie.title}</Link>
                  </td>
                  <td>{movie.genre.name}</td>
                  <td>{movie.dailyRentalRate.toFixed(1)}</td>
                  <td>{movie.numberInStock}</td>
                  <td>
                    {movie.liked ? (
                      <i className="bi bi-heart-fill"></i>
                    ) : (
                      <i className="bi bi-heart"></i>
                    )}
                  </td>
                  <td>
                    <button
                      className="btn btn-danger"
                      onClick={() => dispatch(deleteMovie(movie._id))}
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <Pagination
            totalPage={totalMovies}
            pageSize={pageSize}
            onChangePage={handlePageChange}
            onPreviousChange={handlePreviousChange}
            onNextChange={handleNextChange}
            currentPage={currentPage}
          />

          <div className="d-flex justify-content-center">
            <Link to="/movies/newform">
              <button className="btn btn-success">Add Movie</button>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}

export default MoviesFunc;
